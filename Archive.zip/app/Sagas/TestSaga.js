import { take } from 'redux-saga/effects';
import { TestTypes } from '../Redux/TestRedux';

export function* addQuestions(action) {
  console.log('action before', action.question);
  yield take(TestTypes.ADD_QUESTION1);
  console.log('action after', action.question);
  //yield put(Creators.addQuestion(action.question));
}

export function* addQuestions1(action) {
  console.log('action addQuestions1', action.question);
  //yield put(Creators.addQuestion(action.question));
}
